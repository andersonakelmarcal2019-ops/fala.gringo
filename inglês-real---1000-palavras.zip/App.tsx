import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  CheckCircle, 
  XCircle, 
  BookOpen, 
  Headphones, 
  Smartphone, 
  Star, 
  ChevronDown, 
  ArrowRight,
  ShieldCheck,
  Zap,
  MousePointer2,
  Clock,
  Download,
  Infinity as InfinityIcon
} from 'lucide-react';

// --- Shared Components ---

const CTAButton: React.FC<{ text: string; className?: string; onClick?: () => void }> = ({ text, className, onClick }) => (
  <motion.button
    whileHover={{ scale: 1.05, y: -2 }}
    whileTap={{ scale: 0.98 }}
    onClick={onClick}
    className={`bg-orange-500 hover:bg-orange-600 text-white font-black py-5 px-8 md:px-12 rounded-2xl shadow-xl cta-shadow transition-all duration-300 text-lg md:text-2xl uppercase tracking-tighter flex items-center justify-center gap-3 w-full md:w-auto ${className}`}
  >
    {text}
    <motion.div
      animate={{ x: [0, 5, 0] }}
      transition={{ repeat: Infinity, duration: 1.5 }}
    >
      <ArrowRight className="w-6 h-6 md:w-8 md:h-8" />
    </motion.div>
  </motion.button>
);

const FAQItem: React.FC<{ question: string; answer: string }> = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div className="border-b border-slate-100 last:border-0">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full py-6 flex justify-between items-center text-left hover:text-sky-600 transition-colors"
      >
        <span className="text-lg md:text-xl font-bold pr-8 text-slate-800 leading-tight">{question}</span>
        <motion.div animate={{ rotate: isOpen ? 180 : 0 }}>
          <ChevronDown className="w-6 h-6 text-sky-500" />
        </motion.div>
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <p className="pb-6 text-slate-500 text-lg leading-relaxed">
              {answer}
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

// --- Main Sections ---

const Hero = () => (
  <section className="relative min-h-screen flex flex-col items-center justify-center pt-24 pb-16 overflow-hidden bg-white">
    {/* Abstract Background Accents */}
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-sky-50 rounded-full blur-[120px] -translate-y-1/2"></div>
      <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-indigo-50 rounded-full blur-[120px] translate-y-1/2"></div>
    </div>

    <div className="container mx-auto px-6 relative z-10 text-center">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="inline-flex items-center gap-2 bg-sky-50 border border-sky-100 px-5 py-2 rounded-full text-sky-600 text-xs md:text-sm font-black mb-10 uppercase tracking-widest shadow-sm"
      >
        <Zap className="w-4 h-4 fill-sky-600" />
        Método de Memorização Direta
      </motion.div>

      <motion.h1
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, duration: 0.6 }}
        className="text-4xl md:text-7xl lg:text-8xl font-[900] mb-8 leading-[1] tracking-tighter text-slate-900"
      >
        Apenas 7 Dias e Mais Nada <br />
        <span className="gradient-text italic">e Você Já Entende Inglês!</span>
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.6 }}
        className="text-lg md:text-2xl text-slate-600 max-w-3xl mx-auto mb-12 leading-relaxed font-semibold px-4"
      >
        🤡 Não caia no golpe das escolas de inglês e não pague por curso, apenas decore essas palavras!
      </motion.p>

      {/* Hero Image */}
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.8 }}
        className="mb-16 max-w-3xl mx-auto px-4"
      >
        <div className="relative">
          <div className="absolute inset-0 bg-sky-100 blur-[80px] rounded-full opacity-40 -z-10"></div>
          <img 
            src="https://i.imgur.com/JYNq1RG.png" 
            alt="Ebook e Audiobook Mockup" 
            className="w-full h-auto drop-shadow-[0_35px_35px_rgba(0,0,0,0.15)] hover:scale-[1.02] transition-transform duration-700"
          />
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="flex flex-col items-center gap-6"
      >
        <CTAButton text="SIM! QUERO APRENDER AGORA" />
        <div className="flex items-center gap-2 text-slate-400 font-bold text-sm">
          <MousePointer2 className="w-4 h-4" />
          Acesso Vitalício + Download Imediato
        </div>
      </motion.div>
    </div>
  </section>
);

const Statistics = () => (
  <section className="py-24 px-6 bg-slate-50 border-y border-slate-100">
    <div className="container mx-auto max-w-4xl text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="space-y-6"
        >
          <h3 className="text-3xl md:text-5xl font-[900] leading-tight text-slate-900 uppercase italic tracking-tighter">
            85% do inglês falado usa sempre <br />
            <span className="text-sky-600 underline decoration-sky-300 underline-offset-[12px]">as mesmas palavras.</span>
          </h3>
          <p className="text-xl md:text-2xl text-slate-500 font-medium">
            Aprenda essas palavras e o inglês para de parecer impossível.
          </p>
        </motion.div>
    </div>
  </section>
);

const TargetAudience = () => {
  const list = [
    "Já tentou estudar inglês e sempre desistiu",
    "Já gastou dinheiro com cursos e não aprendeu nada",
    "Acha que inglês é difícil demais pra você",
    "Não tem tempo nem paciência para aulas longas",
    "Quer entender músicas, séries e conversas sem legenda",
    "Acha que 'já passou da idade' para aprender inglês"
  ];

  return (
    <section className="py-24 px-6 bg-white">
      <div className="container mx-auto max-w-5xl">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-black text-slate-900 uppercase mb-4 tracking-tighter">
            👤 Pra quem é <span className="text-sky-600">este método?</span>
          </h2>
          <div className="w-24 h-2 bg-sky-500 mx-auto rounded-full"></div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {list.map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="glass p-6 rounded-3xl flex gap-4 items-center group hover:bg-sky-50 transition-colors"
            >
              <CheckCircle className="w-6 h-6 text-sky-500 shrink-0" />
              <p className="text-slate-700 font-bold text-lg">{item}</p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          className="mt-16 bg-red-50 border-2 border-dashed border-red-200 p-8 rounded-[40px] text-center"
        >
          <p className="text-red-600 font-black text-xl md:text-2xl flex flex-col md:flex-row items-center justify-center gap-3">
            <span className="text-3xl">⚠️</span> Não é para quem quer diploma. É para quem quer entender inglês de verdade.
          </p>
        </motion.div>
      </div>
    </section>
  );
};

const ProductDetails = () => (
  <section className="py-24 px-6 bg-slate-50">
    <div className="container mx-auto max-w-6xl">
      <div className="text-center mb-20">
        <h2 className="text-4xl md:text-7xl font-black mb-6 uppercase text-slate-900 tracking-tighter">
          Aqui não tem <span className="text-sky-600 italic">teoria inútil.</span>
        </h2>
        <p className="text-xl md:text-2xl text-slate-500 max-w-2xl mx-auto">
          Você vai aprender o que realmente aparece em 80% das conversas do dia a dia.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {[
          {
            icon: <BookOpen className="w-10 h-10 text-sky-600" />,
            title: "📘 Ebook",
            features: ["Palavra em inglês", "Tradução em português", "Pronúncia simplificada"]
          },
          {
            icon: <Headphones className="w-10 h-10 text-indigo-600" />,
            title: "🎧 Audiobook",
            features: ["Ouça e repita", "Aprenda no carro ou trabalho", "Sem precisar sentar para 'estudar'"]
          },
          {
            icon: <Smartphone className="w-10 h-10 text-purple-600" />,
            title: "📱 Estude onde quiser",
            features: ["Celular", "Computador", "Tablet"]
          }
        ].map((card, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="glass p-10 rounded-[48px] bg-white hover:border-sky-200 transition-all flex flex-col items-center text-center group"
          >
            <div className="mb-8 p-6 bg-slate-50 rounded-full group-hover:scale-110 transition-transform">
              {card.icon}
            </div>
            <h3 className="text-3xl font-black mb-6 uppercase text-slate-900 italic tracking-tighter">{card.title}</h3>
            <ul className="space-y-4">
              {card.features.map((f, j) => (
                <li key={j} className="text-slate-600 text-lg font-medium flex items-center justify-center gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-sky-500" />
                  {f}
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>

      <div className="mt-20 text-center max-w-3xl mx-auto glass p-10 rounded-[40px] bg-white border-2 border-sky-100">
        <p className="text-2xl md:text-4xl font-black italic text-slate-900 leading-tight">
          "Você não estuda inglês. <br />
          Você decora o que funciona. <br />
          <span className="text-sky-600">E começa a entender.</span>"
        </p>
      </div>
    </div>
  </section>
);

const SocialProof = () => (
  <section className="py-24 px-6 bg-white">
    <div className="container mx-auto max-w-5xl">
      <div className="text-center mb-16">
        <div className="flex justify-center gap-1 mb-6">
          {[1, 2, 3, 4, 5].map(s => <Star key={s} className="w-8 h-8 fill-yellow-400 text-yellow-400" />)}
        </div>
        <h2 className="text-3xl md:text-5xl font-black text-slate-900 tracking-tighter uppercase mb-4">
          Mais de 500 pessoas comuns já começaram a entender inglês.
        </h2>
        <p className="text-xl text-sky-600 font-black">Avaliação média: 4,9 / 5 ⭐</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {[
          { name: "Raimunda Costa", age: 59, text: "Achava que inglês não era pra mim. Em poucos dias já reconheço várias palavras." },
          { name: "Milton Ferreira", age: 72, text: "Nunca pensei que fosse aprender. Esse método é simples demais pra não funcionar." },
          { name: "Renata Mendonça", age: 43, text: "Escuto o áudio enquanto arrumo a casa. Não tem desculpa." }
        ].map((p, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="glass p-8 rounded-3xl bg-slate-50 border border-slate-100 flex flex-col justify-between"
          >
            <div>
              <div className="flex gap-1 mb-4">
                {[1, 2, 3, 4, 5].map(s => <Star key={s} className="w-4 h-4 fill-yellow-400 text-yellow-400" />)}
              </div>
              <p className="text-slate-600 italic text-lg leading-relaxed mb-8">"{p.text}"</p>
            </div>
            <div className="flex items-center gap-4 border-t border-slate-200 pt-6">
              <div className="w-12 h-12 rounded-full bg-sky-100 flex items-center justify-center font-bold text-sky-600 uppercase">
                {p.name[0]}
              </div>
              <div>
                <p className="font-bold text-slate-900 leading-none mb-1">{p.name}</p>
                <p className="text-sm text-slate-400 font-bold uppercase tracking-widest">{p.age} ANOS</p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const Pricing = () => (
  <section className="py-24 px-6 bg-slate-50 relative overflow-hidden">
    <div className="container mx-auto max-w-4xl text-center relative z-10">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        className="glass p-8 md:p-16 rounded-[60px] border-4 border-white bg-white shadow-2xl"
      >
        <div className="inline-block bg-sky-500 text-white px-8 py-2 rounded-full font-black uppercase text-sm tracking-[0.2em] mb-10 shadow-lg shadow-sky-200">
          Oferta por Tempo Limitado
        </div>

        <h2 className="text-4xl md:text-6xl font-black mb-12 uppercase italic text-slate-900 tracking-tighter">O QUE VOCÊ RECEBE HOJE:</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left max-w-2xl mx-auto mb-16">
          {[
            { icon: <CheckCircle className="text-sky-600 w-6 h-6" />, text: "Ebook 1000 Palavras Mais Usadas" },
            { icon: <Headphones className="text-sky-600 w-6 h-6" />, text: "Audiobook para ouvir e repetir" },
            { icon: <BookOpen className="text-sky-600 w-6 h-6" />, text: "Tradução e pronúncia simplificada" },
            { icon: <Download className="text-sky-600 w-6 h-6" />, text: "Download imediato" },
            { icon: <InfinityIcon className="text-sky-600 w-6 h-6" />, text: "Acesso vitalício" },
            { icon: <Clock className="text-sky-600 w-6 h-6" />, text: "Sem mensalidades" },
          ].map((item, i) => (
            <div key={i} className="flex items-center gap-4 text-slate-700 font-bold text-lg">
              {item.icon}
              {item.text}
            </div>
          ))}
        </div>

        <div className="mb-12">
          <p className="text-slate-400 line-through text-2xl font-black mb-2 opacity-50">De R$ 97,00</p>
          <div className="flex items-center justify-center gap-2">
            <span className="text-slate-900 text-3xl font-black mt-4">POR APENAS</span>
            <span className="text-7xl md:text-9xl font-black text-slate-900 tracking-tighter">R$ 29,90</span>
          </div>
        </div>

        <div className="flex flex-col items-center">
          <CTAButton text="QUERO APRENDER AGORA" className="mb-8" />
          <div className="flex flex-col md:flex-row items-center gap-8 text-slate-400 font-bold uppercase tracking-widest text-xs">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-green-500" />
              7 Dias de Garantia Total
            </div>
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-sky-500" />
              Acesso Imediato Após Pagamento
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  </section>
);

const Comparison = () => (
  <section className="py-24 px-6 bg-white">
    <div className="container mx-auto max-w-6xl">
      <div className="text-center mb-20">
        <h2 className="text-4xl md:text-7xl font-black mb-6 uppercase text-slate-900 tracking-tighter italic">⚠️ AGORA A VERDADE:</h2>
        <p className="text-2xl font-black text-sky-600 uppercase tracking-widest">Você tem duas opções</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <motion.div
          whileHover={{ y: -5 }}
          className="bg-red-50/50 border-2 border-red-100 p-10 md:p-14 rounded-[50px] relative overflow-hidden"
        >
          <div className="flex items-center gap-4 mb-10">
            <XCircle className="w-12 h-12 text-red-500" />
            <h3 className="text-2xl font-black text-red-900 uppercase">OPÇÃO 1: CONTINUAR SEM ENTENDER</h3>
          </div>
          <ul className="space-y-6 mb-12">
            {[
              "Desistir toda vez que tenta aprender",
              "Continuar dependendo de legenda e Google Tradutor",
              "Achar que inglês é difícil demais",
              "Ver os outros evoluindo e você parado",
              "Sentir que 'já passou da idade'"
            ].map((text, i) => (
              <li key={i} className="flex items-start gap-3 text-red-800 font-medium text-lg">
                <div className="w-1.5 h-1.5 rounded-full bg-red-400 mt-2 shrink-0" />
                {text}
              </li>
            ))}
          </ul>
          <p className="text-red-600 font-black italic text-xl text-center">👉 Se você não fizer nada, nada muda.</p>
        </motion.div>

        <motion.div
          whileHover={{ y: -5 }}
          className="bg-green-50/50 border-2 border-green-100 p-10 md:p-14 rounded-[50px] relative overflow-hidden"
        >
          <div className="flex items-center gap-4 mb-10">
            <CheckCircle className="w-12 h-12 text-green-500" />
            <h3 className="text-2xl font-black text-green-900 uppercase">OPÇÃO 2: APRENDER EM 7 DIAS</h3>
          </div>
          <ul className="space-y-6 mb-12">
            {[
              "Começar a entender o inglês falado",
              "Reconhecer palavras em séries e músicas",
              "Se sentir orgulhoso por finalmente conseguir",
              "Parar de depender de tradutor",
              "Provar pra si mesmo que você é capaz"
            ].map((text, i) => (
              <li key={i} className="flex items-start gap-3 text-green-800 font-bold text-lg">
                <div className="w-1.5 h-1.5 rounded-full bg-green-400 mt-2 shrink-0" />
                {text}
              </li>
            ))}
          </ul>
          <p className="text-green-600 font-black italic text-xl text-center">👉 A escolha é sua.</p>
        </motion.div>
      </div>

      <div className="mt-16 flex justify-center">
        <CTAButton text="SIM! QUERO APRENDER" />
      </div>
    </div>
  </section>
);

const FAQ = () => {
  const faqs = [
    { question: "Esse método funciona pra quem nunca estudou inglês?", answer: "Sim. Ele foi feito exatamente para iniciantes e pessoas que já desistiram várias vezes por causa de métodos tradicionais chatos." },
    { question: "Preciso estudar muito tempo por dia?", answer: "Não. Com apenas 10 a 15 minutos por dia você já começa a ver resultados significativos." },
    { question: "Vou sair falando inglês em 7 dias?", answer: "Não. Você vai entender o inglês básico e destravar o seu ouvido. A fluência completa vem com a prática, mas o entendimento começa em uma semana." },
    { question: "É indicado para qualquer idade?", answer: "Sim. Temos alunos de 18 a mais de 70 anos. Se você consegue decorar palavras, você consegue aprender." },
    { question: "Posso pagar no Pix ou cartão?", answer: "Sim. Aceitamos Pix (com liberação imediata) e cartão de crédito em até 12x." },
    { question: "Como recebo o material?", answer: "Tudo é enviado automaticamente para o seu e-mail logo após a confirmação do pagamento." },
    { question: "Posso usar sem internet?", answer: "Sim. Você pode baixar os arquivos e ouvir o audiobook ou ler o ebook em qualquer lugar, mesmo offline." },
    { question: "E se eu não gostar?", answer: "Você tem 7 dias de garantia incondicional. Se não gostar, devolvemos 100% do seu dinheiro sem perguntas." }
  ];

  return (
    <section className="py-24 px-6 bg-slate-50">
      <div className="container mx-auto max-w-3xl">
        <h2 className="text-3xl md:text-5xl font-black text-center mb-16 uppercase text-slate-900 tracking-tighter italic">
          ❓ PERGUNTAS <span className="text-sky-600">FREQUENTES</span>
        </h2>
        <div className="glass p-8 md:p-12 rounded-[48px] bg-white border-2 border-slate-100">
          {faqs.map((faq, i) => (
            <FAQItem key={i} question={faq.question} answer={faq.answer} />
          ))}
        </div>
      </div>
    </section>
  );
};

const Footer = () => (
  <footer className="py-24 px-6 bg-white border-t border-slate-100 text-center">
    <div className="container mx-auto max-w-4xl">
      <h2 className="text-3xl md:text-6xl font-black mb-12 uppercase italic text-slate-900 tracking-tighter">
        🚀 VOCÊ PODE CONTINUAR ADIANDO. <br />
        <span className="text-sky-600">OU PODE COMEÇAR AGORA.</span>
      </h2>
      
      <p className="text-xl md:text-2xl text-slate-500 mb-12 font-medium">
        O inglês não é difícil. Difícil é continuar do mesmo jeito.
      </p>

      <div className="flex justify-center mb-20">
        <CTAButton text="SIM! QUERO APRENDER INGLÊS AGORA!" />
      </div>
      
      <div className="pt-12 border-t border-slate-100 flex flex-col md:flex-row justify-between items-center gap-8 text-slate-400 font-bold uppercase tracking-widest text-xs">
        <p>© 2024 INGLÊS REAL. TODOS OS DIREITOS RESERVADOS.</p>
        <div className="flex gap-10">
          <a href="#" className="hover:text-sky-600 transition-colors">Termos</a>
          <a href="#" className="hover:text-sky-600 transition-colors">Privacidade</a>
          <a href="#" className="hover:text-sky-600 transition-colors">Suporte</a>
        </div>
      </div>
    </div>
  </footer>
);

export default function App() {
  return (
    <div className="antialiased overflow-x-hidden selection:bg-sky-500 selection:text-white bg-white">
      <Hero />
      <Statistics />
      <TargetAudience />
      <ProductDetails />
      <SocialProof />
      <Pricing />
      <Comparison />
      <FAQ />
      <Footer />
    </div>
  );
}
